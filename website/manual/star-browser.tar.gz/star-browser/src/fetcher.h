#ifndef __FETCHER_H
#define __FETCHER_H

#include <string>
#pragma once

#endif
